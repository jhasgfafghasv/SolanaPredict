import { pgTable, text, serial, integer, boolean, decimal, timestamp, uuid } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

export const profiles = pgTable("profiles", {
  id: uuid("id").primaryKey().defaultRandom(),
  walletAddress: text("wallet_address").notNull().unique(),
  username: text("username"),
  avatarUrl: text("avatar_url"),
  balance: decimal("balance", { precision: 20, scale: 9 }).default("0").notNull(),
  totalVolume: decimal("total_volume", { precision: 20, scale: 9 }).default("0").notNull(),
  totalBets: integer("total_bets").default(0).notNull(),
  winRate: decimal("win_rate", { precision: 5, scale: 2 }).default("0").notNull(),
  referralCode: text("referral_code").unique(),
  referredBy: uuid("referred_by"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const profileRelations = relations(profiles, ({ one }) => ({
  referrer: one(profiles, {
    fields: [profiles.referredBy],
    references: [profiles.id],
    relationName: "referrals"
  }),
}));

export const predictions = pgTable("predictions", {
  id: uuid("id").primaryKey().defaultRandom(),
  question: text("question").notNull(),
  category: text("category").notNull(),
  endTime: timestamp("end_time").notNull(),
  yesPool: decimal("yes_pool", { precision: 20, scale: 9 }).default("0").notNull(),
  noPool: decimal("no_pool", { precision: 20, scale: 9 }).default("0").notNull(),
  participants: integer("participants").default(0).notNull(),
  status: text("status").default("active").notNull(), // 'active', 'resolved', 'cancelled'
  result: boolean("result"),
  createdBy: uuid("created_by").references(() => profiles.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const bets = pgTable("bets", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: uuid("user_id").references(() => profiles.id).notNull(),
  predictionId: uuid("prediction_id").references(() => predictions.id).notNull(),
  amount: decimal("amount", { precision: 20, scale: 9 }).notNull(),
  position: boolean("position").notNull(), // true for yes, false for no
  potentialPayout: decimal("potential_payout", { precision: 20, scale: 9 }),
  isResolved: boolean("is_resolved").default(false).notNull(),
  actualPayout: decimal("actual_payout", { precision: 20, scale: 9 }).default("0").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const transactions = pgTable("transactions", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: uuid("user_id").references(() => profiles.id).notNull(),
  type: text("type").notNull(), // 'deposit', 'withdrawal', 'bet', 'payout', 'referral_bonus'
  amount: decimal("amount", { precision: 20, scale: 9 }).notNull(),
  status: text("status").default("completed").notNull(), // 'pending', 'completed', 'failed'
  description: text("description"),
  transactionHash: text("transaction_hash"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const chatMessages = pgTable("chat_messages", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: uuid("user_id").references(() => profiles.id).notNull(),
  message: text("message").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const adminSettings = pgTable("admin_settings", {
  id: uuid("id").primaryKey().defaultRandom(),
  key: text("key").unique().notNull(),
  value: text("value").notNull(), // JSON string
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const referralStats = pgTable("referral_stats", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: uuid("user_id").references(() => profiles.id).notNull().unique(),
  totalReferrals: integer("total_referrals").default(0).notNull(),
  totalEarnings: decimal("total_earnings", { precision: 20, scale: 9 }).default("0").notNull(),
  activeReferrals: integer("active_referrals").default(0).notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Insert schemas
export const insertProfileSchema = createInsertSchema(profiles).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertPredictionSchema = createInsertSchema(predictions).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertBetSchema = createInsertSchema(bets).omit({
  id: true,
  createdAt: true,
});

export const insertTransactionSchema = createInsertSchema(transactions).omit({
  id: true,
  createdAt: true,
});

export const insertChatMessageSchema = createInsertSchema(chatMessages).omit({
  id: true,
  createdAt: true,
});

export const insertAdminSettingSchema = createInsertSchema(adminSettings).omit({
  id: true,
  updatedAt: true,
});

export const insertReferralStatsSchema = createInsertSchema(referralStats).omit({
  id: true,
  updatedAt: true,
});

// Types
export type Profile = typeof profiles.$inferSelect;
export type InsertProfile = z.infer<typeof insertProfileSchema>;
export type Prediction = typeof predictions.$inferSelect;
export type InsertPrediction = z.infer<typeof insertPredictionSchema>;
export type Bet = typeof bets.$inferSelect;
export type InsertBet = z.infer<typeof insertBetSchema>;
export type Transaction = typeof transactions.$inferSelect;
export type InsertTransaction = z.infer<typeof insertTransactionSchema>;
export type ChatMessage = typeof chatMessages.$inferSelect;
export type InsertChatMessage = z.infer<typeof insertChatMessageSchema>;
export type AdminSetting = typeof adminSettings.$inferSelect;
export type InsertAdminSetting = z.infer<typeof insertAdminSettingSchema>;
export type ReferralStats = typeof referralStats.$inferSelect;
export type InsertReferralStats = z.infer<typeof insertReferralStatsSchema>;

// Legacy user types for backward compatibility
export const users = profiles;
export type User = Profile;
export type InsertUser = InsertProfile;
export const insertUserSchema = insertProfileSchema;
