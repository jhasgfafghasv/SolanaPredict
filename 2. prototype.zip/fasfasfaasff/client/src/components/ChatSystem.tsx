import { useState, useEffect, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Send, MessageCircle } from 'lucide-react';
import { useApp } from '@/contexts/AppContext';

interface ChatMessage {
  id: string;
  username: string;
  message: string;
  timestamp: Date;
  type: 'user' | 'system' | 'bet';
  betInfo?: {
    prediction: string;
    option: 'yes' | 'no';
    amount: number;
  };
}

const mockMessages: ChatMessage[] = [
  {
    id: '1',
    username: 'CryptoKing',
    message: 'SOL is definitely hitting $200 this month! 🚀',
    timestamp: new Date(Date.now() - 5 * 60 * 1000),
    type: 'user'
  },
  {
    id: '2',
    username: 'System',
    message: 'TraderX just bet 50 SOL on YES for "Will SOL reach $200 by end of month?"',
    timestamp: new Date(Date.now() - 4 * 60 * 1000),
    type: 'bet',
    betInfo: {
      prediction: 'Will SOL reach $200 by end of month?',
      option: 'yes',
      amount: 50
    }
  },
  {
    id: '3',
    username: 'BearMarket',
    message: 'I think we might see a correction first',
    timestamp: new Date(Date.now() - 3 * 60 * 1000),
    type: 'user'
  },
  {
    id: '4',
    username: 'DegenPlayer',
    message: 'LFG! Just doubled down on the Bitcoin ETF prediction',
    timestamp: new Date(Date.now() - 2 * 60 * 1000),
    type: 'user'
  }
];

export const ChatSystem = () => {
  const { state, dispatch } = useApp();
  const [newMessage, setNewMessage] = useState('');
  const scrollAreaRef = useRef<HTMLDivElement>(null);

  // Removed bot messages to only show real user messages

  useEffect(() => {
    // Auto-scroll to bottom when new messages arrive
    if (scrollAreaRef.current) {
      scrollAreaRef.current.scrollTop = scrollAreaRef.current.scrollHeight;
    }
  }, [state.messages]);

  const handleSendMessage = () => {
    if (!newMessage.trim()) return;

    const message: ChatMessage = {
      id: Date.now().toString(),
      username: state.user?.username || 'Anonymous',
      message: newMessage,
      timestamp: new Date(),
      type: 'user'
    };

    dispatch({ type: 'ADD_MESSAGE', payload: message });
    setNewMessage('');
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSendMessage();
    }
  };

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  const getUsernameColor = (username: string) => {
    const colors = [
      'text-blue-500',
      'text-green-500',
      'text-purple-500',
      'text-pink-500',
      'text-yellow-500',
      'text-cyan-500'
    ];
    const index = username.length % colors.length;
    return colors[index];
  };

  return (
    <Card className="h-full flex flex-col">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2">
          <MessageCircle className="h-5 w-5" />
          Live Chat
          <Badge variant="secondary" className="ml-auto">
            {state.messages.filter(m => m.type === 'user').length} users
          </Badge>
        </CardTitle>
      </CardHeader>

      <CardContent className="flex-1 flex flex-col gap-4 p-4">
        <ScrollArea className="flex-1 h-48 max-h-48" ref={scrollAreaRef}>
          <div className="space-y-3">
            {state.messages.map((message) => (
              <div key={message.id} className="space-y-1">
                {message.type === 'bet' ? (
                  <div className="bg-accent/50 rounded-lg p-3 border-l-4 border-primary">
                    <div className="text-sm font-medium text-primary">🎯 New Bet Alert</div>
                    <div className="text-sm text-muted-foreground">
                      <span className="font-medium">{message.username}</span> bet{' '}
                      <span className="font-bold text-foreground">
                        {message.betInfo?.amount} SOL
                      </span>{' '}
                      on{' '}
                      <Badge
                        variant={message.betInfo?.option === 'yes' ? 'default' : 'destructive'}
                        className="mx-1"
                      >
                        {message.betInfo?.option.toUpperCase()}
                      </Badge>
                    </div>
                  </div>
                ) : (
                  <div className="flex items-start gap-2">
                    <Avatar className="h-6 w-6">
                      <AvatarFallback className="text-xs">
                        {message.username.slice(0, 2).toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className={`text-sm font-medium ${getUsernameColor(message.username)}`}>
                          {message.username}
                        </span>
                        <span className="text-xs text-muted-foreground">
                          {formatTime(message.timestamp)}
                        </span>
                      </div>
                      <div className="text-sm text-foreground break-words">
                        {message.message}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </ScrollArea>

        <div className="flex gap-2">
          <Input
            placeholder="Type a message..."
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            onKeyPress={handleKeyPress}
            className="flex-1"
          />
          <Button onClick={handleSendMessage} size="icon">
            <Send className="h-4 w-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};