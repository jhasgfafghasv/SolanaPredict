import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Settings, Plus, Edit, Trash2, DollarSign, Users, TrendingUp, BarChart3 } from 'lucide-react';
import { useApp } from '@/contexts/AppContext';
import { useToast } from '@/hooks/use-toast';

interface AdminSettings {
  houseEdge: number;
  minBetAmount: number;
  maxBetAmount: number;
  platformFee: number;
  autoResolve: boolean;
}

export const AdminPortal = () => {
  const { state, dispatch } = useApp();
  const { toast } = useToast();
  const [isOpen, setIsOpen] = useState(false);
  
  // New prediction form
  const [newPrediction, setNewPrediction] = useState({
    question: '',
    category: 'crypto',
    endTime: '',
    initialPool: 100
  });

  // Admin settings
  const [adminSettings, setAdminSettings] = useState<AdminSettings>({
    houseEdge: 10, // 10% house edge on losses
    minBetAmount: 0.1,
    maxBetAmount: 1000,
    platformFee: 2, // 2% platform fee
    autoResolve: false
  });

  // Use global predictions state
  const predictions = state.predictions;

  const handleCreatePrediction = () => {
    if (!newPrediction.question || !newPrediction.endTime) {
      toast({
        title: "Invalid Prediction",
        description: "Please fill in all required fields",
        variant: "destructive"
      });
      return;
    }

    const prediction = {
      id: Date.now().toString(),
      question: newPrediction.question,
      category: newPrediction.category,
      endTime: new Date(newPrediction.endTime),
      totalPool: newPrediction.initialPool,
      yesPool: newPrediction.initialPool * 0.5,
      noPool: newPrediction.initialPool * 0.5,
      participants: 0,
      status: 'active' as const
    };

    dispatch({
      type: 'ADD_PREDICTION',
      payload: prediction
    });
    
    // Add to chat system
    dispatch({
      type: 'ADD_MESSAGE',
      payload: {
        id: Date.now().toString(),
        username: 'Admin',
        message: `New prediction market created: "${prediction.question}"`,
        timestamp: new Date(),
        type: 'system'
      }
    });
    
    // Reset form
    setNewPrediction({
      question: '',
      category: 'crypto',
      endTime: '',
      initialPool: 100
    });

    toast({
      title: "Prediction Created",
      description: "New prediction market has been created successfully!"
    });
  };

  const handleResolvePrediction = (predictionId: string, result: 'yes' | 'no') => {
    dispatch({
      type: 'RESOLVE_PREDICTION',
      payload: { id: predictionId, result }
    });

    // Calculate payouts with house edge
    const prediction = predictions.find(p => p.id === predictionId);
    if (prediction) {
      const winningPool = result === 'yes' ? prediction.yesPool : prediction.noPool;
      const losingPool = result === 'yes' ? prediction.noPool : prediction.yesPool;
      const houseEdgeAmount = losingPool * (adminSettings.houseEdge / 100);
      const availableForPayout = losingPool - houseEdgeAmount;

      dispatch({
        type: 'ADD_MESSAGE',
        payload: {
          id: Date.now().toString(),
          username: 'System',
          message: `Prediction resolved: "${prediction.question}" - Result: ${result.toUpperCase()}. House collected ${houseEdgeAmount.toFixed(2)} SOL (${adminSettings.houseEdge}%)`,
          timestamp: new Date(),
          type: 'system'
        }
      });
    }

    toast({
      title: "Prediction Resolved",
      description: `Prediction resolved as ${result.toUpperCase()}. Payouts distributed!`
    });
  };

  const handleDeletePrediction = (predictionId: string) => {
    dispatch({
      type: 'DELETE_PREDICTION',
      payload: predictionId
    });
    
    dispatch({
      type: 'ADD_MESSAGE',
      payload: {
        id: Date.now().toString(),
        username: 'Admin',
        message: `Prediction deleted: "${predictions.find(p => p.id === predictionId)?.question}"`,
        timestamp: new Date(),
        type: 'system'
      }
    });
    
    toast({
      title: "Prediction Deleted",
      description: "Prediction has been removed from the platform"
    });
  };

  const handleUpdateSettings = () => {
    // In a real app, this would save to backend
    toast({
      title: "Settings Updated",
      description: "Platform settings have been updated successfully!"
    });
  };

  // Check if user is admin using your specific wallet address
  const isAdmin = state.user?.walletAddress === 'CBF9xK2T7FhWk6wafZHujJUugbNJRND22b3foRZgxhbR';

  if (!isAdmin || !state.user) {
    return null; // Hide the button completely for non-admin users
  }

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm">
          <Settings className="h-4 w-4 mr-2" />
          Admin Portal
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Admin Portal</DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="predictions" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="predictions">Predictions</TabsTrigger>
            <TabsTrigger value="create">Create New</TabsTrigger>
            <TabsTrigger value="settings">Settings</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
          </TabsList>

          {/* Manage Predictions */}
          <TabsContent value="predictions" className="space-y-4">
            <div className="grid gap-4">
              {predictions.map((prediction) => (
                <Card key={prediction.id}>
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle className="text-lg">{prediction.question}</CardTitle>
                        <div className="flex gap-2 mt-2">
                          <Badge variant="secondary">{prediction.category}</Badge>
                          <Badge variant={
                            prediction.status === 'active' ? 'default' :
                            prediction.status === 'resolved' ? 'destructive' : 'outline'
                          }>
                            {prediction.status}
                          </Badge>
                        </div>
                      </div>
                      <div className="flex gap-2">
                        {prediction.status === 'active' && (
                          <>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleResolvePrediction(prediction.id, 'yes')}
                            >
                              Resolve YES
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleResolvePrediction(prediction.id, 'no')}
                            >
                              Resolve NO
                            </Button>
                          </>
                        )}
                        <Button
                          size="sm"
                          variant="destructive"
                          onClick={() => handleDeletePrediction(prediction.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-4 gap-4 text-sm">
                      <div>
                        <div className="text-muted-foreground">Total Pool</div>
                        <div className="font-medium">{prediction.totalPool.toFixed(2)} SOL</div>
                      </div>
                      <div>
                        <div className="text-muted-foreground">YES Pool</div>
                        <div className="font-medium text-green-600">{prediction.yesPool.toFixed(2)} SOL</div>
                      </div>
                      <div>
                        <div className="text-muted-foreground">NO Pool</div>
                        <div className="font-medium text-red-600">{prediction.noPool.toFixed(2)} SOL</div>
                      </div>
                      <div>
                        <div className="text-muted-foreground">Participants</div>
                        <div className="font-medium">{prediction.participants}</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Create New Prediction */}
          <TabsContent value="create" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Create New Prediction Market</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="question">Question</Label>
                  <Textarea
                    id="question"
                    placeholder="e.g., Will Bitcoin reach $100,000 by end of 2024?"
                    value={newPrediction.question}
                    onChange={(e) => setNewPrediction(prev => ({ ...prev, question: e.target.value }))}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="category">Category</Label>
                    <Select 
                      value={newPrediction.category}
                      onValueChange={(value) => setNewPrediction(prev => ({ ...prev, category: value }))}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="crypto">Crypto</SelectItem>
                        <SelectItem value="finance">Finance</SelectItem>
                        <SelectItem value="stocks">Stocks</SelectItem>
                        <SelectItem value="sports">Sports</SelectItem>
                        <SelectItem value="politics">Politics</SelectItem>
                        <SelectItem value="weather">Weather</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="endTime">End Time</Label>
                    <Input
                      id="endTime"
                      type="datetime-local"
                      value={newPrediction.endTime}
                      onChange={(e) => setNewPrediction(prev => ({ ...prev, endTime: e.target.value }))}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="initialPool">Initial Pool (SOL)</Label>
                  <Input
                    id="initialPool"
                    type="number"
                    min="10"
                    value={newPrediction.initialPool}
                    onChange={(e) => setNewPrediction(prev => ({ ...prev, initialPool: parseFloat(e.target.value) || 0 }))}
                  />
                </div>

                <Button onClick={handleCreatePrediction} className="w-full">
                  <Plus className="h-4 w-4 mr-2" />
                  Create Prediction Market
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Settings */}
          <TabsContent value="settings" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Platform Settings</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="houseEdge">House Edge (%)</Label>
                    <Input
                      id="houseEdge"
                      type="number"
                      min="0"
                      max="50"
                      value={adminSettings.houseEdge}
                      onChange={(e) => setAdminSettings(prev => ({ 
                        ...prev, 
                        houseEdge: parseFloat(e.target.value) || 0 
                      }))}
                    />
                    <p className="text-sm text-muted-foreground">
                      Percentage taken from losing bets
                    </p>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="platformFee">Platform Fee (%)</Label>
                    <Input
                      id="platformFee"
                      type="number"
                      min="0"
                      max="10"
                      value={adminSettings.platformFee}
                      onChange={(e) => setAdminSettings(prev => ({ 
                        ...prev, 
                        platformFee: parseFloat(e.target.value) || 0 
                      }))}
                    />
                    <p className="text-sm text-muted-foreground">
                      Fee on all transactions
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="minBet">Minimum Bet (SOL)</Label>
                    <Input
                      id="minBet"
                      type="number"
                      min="0.01"
                      step="0.01"
                      value={adminSettings.minBetAmount}
                      onChange={(e) => setAdminSettings(prev => ({ 
                        ...prev, 
                        minBetAmount: parseFloat(e.target.value) || 0 
                      }))}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="maxBet">Maximum Bet (SOL)</Label>
                    <Input
                      id="maxBet"
                      type="number"
                      min="1"
                      value={adminSettings.maxBetAmount}
                      onChange={(e) => setAdminSettings(prev => ({ 
                        ...prev, 
                        maxBetAmount: parseFloat(e.target.value) || 0 
                      }))}
                    />
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="autoResolve">Auto-resolve predictions</Label>
                    <p className="text-sm text-muted-foreground">
                      Automatically resolve predictions when they expire
                    </p>
                  </div>
                  <Switch
                    id="autoResolve"
                    checked={adminSettings.autoResolve}
                    onCheckedChange={(checked) => setAdminSettings(prev => ({ 
                      ...prev, 
                      autoResolve: checked 
                    }))}
                  />
                </div>

                <Button onClick={handleUpdateSettings} className="w-full">
                  Update Settings
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Analytics */}
          <TabsContent value="analytics" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">Total Volume</p>
                      <p className="text-2xl font-bold">
                        {state.bets.reduce((total, bet) => total + bet.amount, 0).toFixed(2)} SOL
                      </p>
                    </div>
                    <DollarSign className="h-8 w-8 text-green-500" />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">Active Predictions</p>
                      <p className="text-2xl font-bold">{predictions.filter(p => p.status === 'active').length}</p>
                    </div>
                    <BarChart3 className="h-8 w-8 text-blue-500" />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">Total Bets</p>
                      <p className="text-2xl font-bold">{state.bets.length}</p>
                    </div>
                    <TrendingUp className="h-8 w-8 text-purple-500" />
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Referral System Settings */}
            <Card>
              <CardHeader>
                <CardTitle>Referral System</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="referralPercentage">Referral Percentage (%)</Label>
                    <Input
                      id="referralPercentage"
                      type="number"
                      min="0"
                      max="20"
                      value={5}
                      readOnly
                    />
                    <p className="text-sm text-muted-foreground">
                      Percentage of referral betting volume given as rewards
                    </p>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="totalReferrals">Total Referrals</Label>
                    <Input
                      id="totalReferrals"
                      value={Object.values(state.referralStats).reduce((total, stats) => total + stats.totalReferrals, 0)}
                      readOnly
                    />
                    <p className="text-sm text-muted-foreground">
                      Total users referred to the platform
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Referral Volume</Label>
                    <Input
                      value={`${Object.values(state.referralStats).reduce((total, stats) => total + stats.totalVolume, 0).toFixed(2)} SOL`}
                      readOnly
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Referral Earnings</Label>
                    <Input
                      value={`${Object.values(state.referralStats).reduce((total, stats) => total + stats.earnings, 0).toFixed(2)} SOL`}
                      readOnly
                    />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Recent Activity */}
            <Card>
              <CardHeader>
                <CardTitle>Recent Platform Activity</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {state.messages.slice(-5).reverse().map((message) => (
                    <div key={message.id} className="flex justify-between items-center p-3 bg-accent/30 rounded">
                      <div>
                        <p className="font-medium text-sm">{message.username}</p>
                        <p className="text-xs text-muted-foreground">{message.message}</p>
                      </div>
                      <span className="text-xs text-muted-foreground">
                        {new Date(message.timestamp).toLocaleTimeString()}
                      </span>
                    </div>
                  ))}
                  {state.messages.length === 0 && (
                    <p className="text-center text-muted-foreground py-4">
                      No recent activity
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
};