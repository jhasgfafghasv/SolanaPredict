import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { TrendingUp, TrendingDown, Clock, Users, DollarSign } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useApp } from '@/contexts/AppContext';
import { useToast } from '@/hooks/use-toast';

interface Prediction {
  id: string;
  question: string;
  category: string;
  endTime: Date;
  totalPool: number;
  yesPool: number;
  noPool: number;
  participants: number;
  status: 'active' | 'ended' | 'resolved';
  result?: 'yes' | 'no';
}

export const PredictionMarket = () => {
  // Use global predictions state instead of local state
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const { state, dispatch } = useApp();
  const predictions = state.predictions;

  const categories = ['all', 'crypto', 'finance', 'stocks', 'sports'];

  const filteredPredictions = predictions.filter(p => 
    selectedCategory === 'all' || p.category.toLowerCase() === selectedCategory
  );

  const getTimeRemaining = (endTime: Date) => {
    const now = new Date();
    const diff = endTime.getTime() - now.getTime();
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    return `${hours}h ${minutes}m`;
  };

  const getYesPercentage = (prediction: Prediction) => {
    return (prediction.yesPool / prediction.totalPool) * 100;
  };

  const getNoPercentage = (prediction: Prediction) => {
    return (prediction.noPool / prediction.totalPool) * 100;
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
          Prediction Markets
        </h1>
        <p className="text-muted-foreground max-w-2xl mx-auto">
          Trade on the outcome of real-world events. Fast, fair, and powered by Solana.
        </p>
      </div>

      {/* Category Filter */}
      <Tabs value={selectedCategory} onValueChange={setSelectedCategory} className="w-full">
        <TabsList className="grid w-full grid-cols-5">
          {categories.map((category) => (
            <TabsTrigger key={category} value={category} className="capitalize">
              {category}
            </TabsTrigger>
          ))}
        </TabsList>

        <TabsContent value={selectedCategory} className="mt-6">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {filteredPredictions.map((prediction) => (
              <PredictionCard 
                key={prediction.id} 
                prediction={prediction} 
                onBet={(predictionId, option, amount) => {
                  // Update prediction pools with 10% house edge calculation
                  const prediction = predictions.find(p => p.id === predictionId);
                  if (prediction) {
                    // Apply house edge (10% of bet amount goes to house)
                    const houseEdge = amount * 0.10;
                    const netAmount = amount - houseEdge;
                    
                    const newYes = option === 'yes' ? prediction.yesPool + netAmount : prediction.yesPool;
                    const newNo = option === 'no' ? prediction.noPool + netAmount : prediction.noPool;
                    
                    // Update prediction pools
                    dispatch({
                      type: 'UPDATE_PREDICTION_POOLS',
                      payload: {
                        id: predictionId,
                        yesPool: newYes,
                        noPool: newNo,
                        participants: prediction.participants + 1
                      }
                    });
                    
                    // Apply house edge
                    dispatch({ 
                      type: 'APPLY_HOUSE_EDGE', 
                      payload: { amount: houseEdge, percentage: 10 } 
                    });
                  }
                  
                  // Create bet record
                  const bet = {
                    id: Date.now().toString(),
                    predictionId,
                    userId: state.user?.walletAddress || '',
                    option,
                    amount,
                    timestamp: new Date()
                  };
                  
                  dispatch({ type: 'PLACE_BET', payload: bet });
                  dispatch({ type: 'UPDATE_BALANCE', payload: (state.user?.balance || 0) - amount });
                  
                  // Add bet message to chat
                  const message = {
                    id: Date.now().toString(),
                    username: state.user?.username || 'Anonymous',
                    message: `Bet ${amount} SOL on ${option.toUpperCase()}`,
                    timestamp: new Date(),
                    type: 'bet',
                    betInfo: {
                      prediction: prediction.question,
                      option,
                      amount
                    }
                  };
                  dispatch({ type: 'ADD_MESSAGE', payload: message });
                }}
              />
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

interface PredictionCardProps {
  prediction: Prediction;
  onBet: (predictionId: string, option: 'yes' | 'no', amount: number) => void;
}

const PredictionCard = ({ prediction, onBet }: PredictionCardProps) => {
  const [selectedOption, setSelectedOption] = useState<'yes' | 'no' | null>(null);
  const [betAmount, setBetAmount] = useState<number>(1);
  const [isPlacingBet, setIsPlacingBet] = useState(false);
  const { state } = useApp();
  const { toast } = useToast();

  const yesPercentage = (prediction.yesPool / prediction.totalPool) * 100;
  const noPercentage = (prediction.noPool / prediction.totalPool) * 100;

  const handleBet = async (option: 'yes' | 'no') => {
    if (!state.user) {
      toast({
        title: "Wallet Required",
        description: "Please connect your wallet to place bets",
        variant: "destructive"
      });
      return;
    }
    
    if (betAmount <= 0 || betAmount > (state.user.balance || 0)) {
      toast({
        title: "Invalid Amount",
        description: "Please enter a valid bet amount",
        variant: "destructive"
      });
      return;
    }
    
    setIsPlacingBet(true);
    
    try {
      // Simulate transaction delay
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      onBet(prediction.id, option, betAmount);
      setSelectedOption(option);
      
      toast({
        title: "Bet Placed!",
        description: `Successfully bet ${betAmount} SOL on ${option.toUpperCase()}`,
      });
    } catch (error) {
      toast({
        title: "Bet Failed",
        description: "Failed to place bet. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsPlacingBet(false);
    }
  };

  return (
    <Card className="overflow-hidden hover:shadow-lg transition-shadow duration-300">
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <Badge variant="secondary" className="mb-2">
            {prediction.category}
          </Badge>
          <div className="flex items-center gap-1 text-sm text-muted-foreground">
            <Clock className="h-3 w-3" />
            {prediction.endTime > new Date() ? 
              getTimeRemaining(prediction.endTime) : 
              'Ended'
            }
          </div>
        </div>
        <CardTitle className="text-lg leading-tight">
          {prediction.question}
        </CardTitle>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Pool Info */}
        <div className="flex items-center justify-between text-sm">
          <div className="flex items-center gap-1">
            <DollarSign className="h-3 w-3" />
            <span className="font-medium">{prediction.totalPool.toFixed(2)} SOL</span>
          </div>
          <div className="flex items-center gap-1 text-muted-foreground">
            <Users className="h-3 w-3" />
            <span>{prediction.participants}</span>
          </div>
        </div>

        {/* Odds Display */}
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span>YES {yesPercentage.toFixed(1)}%</span>
            <span>NO {noPercentage.toFixed(1)}%</span>
          </div>
          <Progress value={yesPercentage} className="h-2" />
        </div>

        {/* Betting Amount Input */}
        <div className="space-y-2">
          <label className="text-sm font-medium">Bet Amount (SOL)</label>
          <Input
            type="number"
            step="0.001"
            min="0.001"
            max={state.user?.balance || 0}
            value={betAmount}
            onChange={(e) => setBetAmount(parseFloat(e.target.value) || 0)}
            className="text-center"
            placeholder="Enter amount"
          />
          <div className="text-xs text-muted-foreground text-center">
            Available: {state.user?.balance.toFixed(2) || '0.00'} SOL
          </div>
        </div>

        {/* Betting Options */}
        <div className="grid grid-cols-2 gap-2">
          <Button
            variant={selectedOption === 'yes' ? 'default' : 'outline'}
            className={cn(
              'flex items-center gap-2 h-12',
              selectedOption === 'yes' && 'bg-green-600 hover:bg-green-700'
            )}
            onClick={() => handleBet('yes')}
            disabled={isPlacingBet || !state.user}
          >
            <TrendingUp className="h-4 w-4" />
            <div className="text-left">
              <div className="text-sm font-medium">YES</div>
              <div className="text-xs opacity-80">{(100 / yesPercentage * 100).toFixed(1)}x</div>
            </div>
          </Button>

          <Button
            variant={selectedOption === 'no' ? 'default' : 'outline'}
            className={cn(
              'flex items-center gap-2 h-12',
              selectedOption === 'no' && 'bg-red-600 hover:bg-red-700'
            )}
            onClick={() => handleBet('no')}
            disabled={isPlacingBet || !state.user}
          >
            <TrendingDown className="h-4 w-4" />
            <div className="text-left">
              <div className="text-sm font-medium">NO</div>
              <div className="text-xs opacity-80">{(100 / noPercentage * 100).toFixed(1)}x</div>
            </div>
          </Button>
        </div>

        {/* Pool Breakdown */}
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div className="text-center p-2 bg-green-50 dark:bg-green-950/20 rounded">
            <div className="font-medium text-green-700 dark:text-green-300">YES Pool</div>
            <div className="text-green-600 dark:text-green-400">{prediction.yesPool.toFixed(2)} SOL</div>
          </div>
          <div className="text-center p-2 bg-red-50 dark:bg-red-950/20 rounded">
            <div className="font-medium text-red-700 dark:text-red-300">NO Pool</div>
            <div className="text-red-600 dark:text-red-400">{prediction.noPool.toFixed(2)} SOL</div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

const getTimeRemaining = (endTime: Date) => {
  const now = new Date();
  const diff = endTime.getTime() - now.getTime();
  const hours = Math.floor(diff / (1000 * 60 * 60));
  const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
  return `${hours}h ${minutes}m`;
};