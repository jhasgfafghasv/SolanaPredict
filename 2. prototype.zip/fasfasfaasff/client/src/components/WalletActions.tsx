import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ArrowDownToLine, ArrowUpFromLine, Wallet } from 'lucide-react';
import { useApp } from '@/contexts/AppContext';
import { useToast } from '@/hooks/use-toast';

export const WalletActions = () => {
  const { state, dispatch } = useApp();
  const { toast } = useToast();
  const [depositAmount, setDepositAmount] = useState('');
  const [withdrawAmount, setWithdrawAmount] = useState('');

  const handleDeposit = () => {
    const amount = parseFloat(depositAmount);
    if (!amount || amount <= 0 || isNaN(amount)) {
      toast({
        title: "Invalid Amount",
        description: "Please enter a valid deposit amount (minimum 0.001 SOL)",
        variant: "destructive"
      });
      return;
    }

    if (amount < 0.001) {
      toast({
        title: "Amount Too Small",
        description: "Minimum deposit is 0.001 SOL",
        variant: "destructive"
      });
      return;
    }

    // In a real app, this would interact with Solana wallet
    const newBalance = (state.user?.balance || 0) + amount;
    dispatch({ type: 'UPDATE_BALANCE', payload: newBalance });
    
    toast({
      title: "Deposit Successful",
      description: `Deposited ${amount} SOL to your account`
    });
    
    setDepositAmount('');
  };

  const handleWithdraw = () => {
    const amount = parseFloat(withdrawAmount);
    if (!amount || amount <= 0 || isNaN(amount)) {
      toast({
        title: "Invalid Amount",
        description: "Please enter a valid withdrawal amount (minimum 0.001 SOL)",
        variant: "destructive"
      });
      return;
    }

    if (amount < 0.001) {
      toast({
        title: "Amount Too Small", 
        description: "Minimum withdrawal is 0.001 SOL",
        variant: "destructive"
      });
      return;
    }

    if (amount > (state.user?.balance || 0)) {
      toast({
        title: "Insufficient Balance",
        description: "You don't have enough SOL to withdraw",
        variant: "destructive"
      });
      return;
    }

    // In a real app, this would interact with Solana wallet
    const newBalance = (state.user?.balance || 0) - amount;
    dispatch({ type: 'UPDATE_BALANCE', payload: newBalance });
    
    toast({
      title: "Withdrawal Successful",
      description: `Withdrawn ${amount} SOL from your account`
    });
    
    setWithdrawAmount('');
  };

  if (!state.isWalletConnected) {
    return null;
  }

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm">
          <Wallet className="h-4 w-4 mr-2" />
          Manage Funds
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Wallet Actions</DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="deposit" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="deposit">Deposit</TabsTrigger>
            <TabsTrigger value="withdraw">Withdraw</TabsTrigger>
          </TabsList>

          <TabsContent value="deposit" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <ArrowDownToLine className="h-5 w-5 text-green-500" />
                  Deposit SOL
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="deposit-amount">Amount (SOL)</Label>
                  <Input
                    id="deposit-amount"
                    type="number"
                    step="0.001"
                    min="0"
                    value={depositAmount}
                    onChange={(e) => setDepositAmount(e.target.value)}
                    placeholder="0.000"
                  />
                </div>
                <Button onClick={handleDeposit} className="w-full">
                  <ArrowDownToLine className="h-4 w-4 mr-2" />
                  Deposit SOL
                </Button>
                <p className="text-xs text-muted-foreground">
                  Minimum deposit: 0.001 SOL
                </p>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="withdraw" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <ArrowUpFromLine className="h-5 w-5 text-blue-500" />
                  Withdraw SOL
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="withdraw-amount">Amount (SOL)</Label>
                  <Input
                    id="withdraw-amount"
                    type="number"
                    step="0.001"
                    min="0"
                    max={state.user?.balance || 0}
                    value={withdrawAmount}
                    onChange={(e) => setWithdrawAmount(e.target.value)}
                    placeholder="0.000"
                  />
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>Available: {(state.user?.balance || 0).toFixed(6)} SOL</span>
                    <Button
                      variant="link"
                      size="sm"
                      className="h-auto p-0 text-xs"
                      onClick={() => setWithdrawAmount((state.user?.balance || 0).toString())}
                    >
                      Max
                    </Button>
                  </div>
                </div>
                <Button onClick={handleWithdraw} className="w-full">
                  <ArrowUpFromLine className="h-4 w-4 mr-2" />
                  Withdraw SOL
                </Button>
                <p className="text-xs text-muted-foreground">
                  Minimum withdrawal: 0.001 SOL
                </p>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
};