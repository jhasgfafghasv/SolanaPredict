import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Wallet, Copy, ExternalLink, Loader } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useSolanaWallet } from '@/hooks/useSolanaWallet';
import { useApp } from '@/contexts/AppContext';

export const WalletConnect = () => {
  const { state, dispatch } = useApp();
  const { connectWallet, disconnectWallet, isConnecting } = useSolanaWallet();
  const { toast } = useToast();

  const handleConnect = async () => {
    try {
      const wallet = await connectWallet();
      
      const user = {
        walletAddress: wallet.address,
        balance: wallet.balance,
        username: `User${wallet.address.slice(-4)}`,
        totalBets: 0,
        profit: 0,
        winRate: 0
      };
      
      dispatch({ type: 'CONNECT_WALLET', payload: user });
    } catch (error) {
      console.error('Connection failed:', error);
    }
  };

  const handleDisconnect = async () => {
    await disconnectWallet();
    dispatch({ type: 'DISCONNECT_WALLET' });
  };

  const copyAddress = () => {
    if (state.user?.walletAddress) {
      navigator.clipboard.writeText(state.user.walletAddress);
      toast({
        title: "Address Copied",
        description: "Wallet address copied to clipboard",
      });
    }
  };

  const formatAddress = (address: string) => {
    if (!address) return '';
    return `${address.slice(0, 4)}...${address.slice(-4)}`;
  };

  if (!state.isWalletConnected) {
    return (
      <Card className="w-full max-w-md mx-auto">
        <CardHeader className="text-center">
          <CardTitle className="flex items-center justify-center gap-2">
            <Wallet className="h-5 w-5" />
            Connect Wallet
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-center text-muted-foreground">
            Connect your Solana wallet to start trading on prediction markets
          </p>
          <Button onClick={handleConnect} className="w-full" size="lg" disabled={isConnecting}>
            {isConnecting ? (
              <Loader className="h-4 w-4 mr-2 animate-spin" />
            ) : (
              <Wallet className="h-4 w-4 mr-2" />
            )}
            {isConnecting ? 'Connecting...' : 'Connect Solana Wallet'}
          </Button>
          <div className="text-xs text-center text-muted-foreground">
            Supported wallets: Phantom, Solflare, Backpack
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="w-full max-w-md">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Wallet className="h-5 w-5" />
            Wallet
          </div>
          <Badge variant="default" className="bg-green-600">
            Connected
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-sm text-muted-foreground">Address</span>
            <div className="flex items-center gap-2">
              <span className="text-sm font-mono">{formatAddress(state.user?.walletAddress || '')}</span>
              <Button variant="ghost" size="icon" className="h-6 w-6" onClick={copyAddress}>
                <Copy className="h-3 w-3" />
              </Button>
              <Button variant="ghost" size="icon" className="h-6 w-6">
                <ExternalLink className="h-3 w-3" />
              </Button>
            </div>
          </div>
          
          <div className="flex items-center justify-between">
            <span className="text-sm text-muted-foreground">Balance</span>
            <span className="text-lg font-bold">{(state.user?.balance || 0).toFixed(6)} SOL</span>
          </div>
        </div>

        <div className="pt-4 border-t space-y-2">
          <Button variant="outline" onClick={handleConnect} className="w-full">
            Change Wallet
          </Button>
          <Button variant="outline" onClick={handleDisconnect} className="w-full">
            Disconnect Wallet
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};