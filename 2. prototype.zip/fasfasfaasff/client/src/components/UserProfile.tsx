import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { User, Edit, Upload, Trophy, TrendingUp, Target, DollarSign, Copy, Share2, Users } from 'lucide-react';
import { useApp } from '@/contexts/AppContext';
import { useToast } from '@/hooks/use-toast';

// Users should upload their own profile pictures

interface UserProfileProps {
  trigger?: React.ReactNode;
}

export const UserProfile = ({ trigger }: UserProfileProps) => {
  const { state, dispatch } = useApp();
  const { toast } = useToast();
  const [isEditing, setIsEditing] = useState(false);
  const [newUsername, setNewUsername] = useState(state.user?.username || '');
  const [selectedAvatar, setSelectedAvatar] = useState(state.user?.profilePicture || '');
  const [referralCode, setReferralCode] = useState('');
  
  // Generate referral code and link
  const userReferralCode = state.user?.referralCode || state.user?.walletAddress.slice(0, 8).toUpperCase();
  const referralLink = `${window.location.origin}?ref=${userReferralCode}`;
  const userReferralStats = state.referralStats[state.user?.walletAddress || ''] || { totalReferrals: 0, totalVolume: 0, earnings: 0 };

  const handleSaveProfile = () => {
    if (!newUsername.trim()) {
      toast({
        title: "Invalid Username",
        description: "Username cannot be empty",
        variant: "destructive"
      });
      return;
    }

    dispatch({
      type: 'UPDATE_USER_PROFILE',
      payload: {
        username: newUsername,
        profilePicture: selectedAvatar
      }
    });

    toast({
      title: "Profile Updated",
      description: "Your profile has been updated successfully!"
    });

    setIsEditing(false);
  };

  const copyReferralLink = () => {
    navigator.clipboard.writeText(referralLink);
    toast({
      title: "Copied!",
      description: "Referral link copied to clipboard"
    });
  };

  const copyReferralCode = () => {
    navigator.clipboard.writeText(userReferralCode);
    toast({
      title: "Copied!",
      description: "Referral code copied to clipboard"
    });
  };

  const applyReferralCode = () => {
    if (!referralCode.trim()) {
      toast({
        title: "Invalid Code",
        description: "Please enter a valid referral code",
        variant: "destructive"
      });
      return;
    }

    if (referralCode === userReferralCode) {
      toast({
        title: "Invalid Code",
        description: "You cannot use your own referral code",
        variant: "destructive"
      });
      return;
    }

    if (state.user?.referredBy) {
      toast({
        title: "Already Referred",
        description: "You have already used a referral code",
        variant: "destructive"
      });
      return;
    }

    // For now, accept any referral code that follows the pattern (starts with letters/numbers)
    // In a real app, this would validate against the backend database
    const isValidCode = /^[A-Z0-9]{6,}$/.test(referralCode.toUpperCase());
    if (!isValidCode) {
      toast({
        title: "Invalid Code",
        description: "Please enter a valid referral code",
        variant: "destructive"
      });
      return;
    }

    // Apply referral code
    dispatch({
      type: 'APPLY_REFERRAL_CODE',
      payload: {
        walletAddress: state.user?.walletAddress || '',
        referralCode: referralCode
      }
    });

    toast({
      title: "Referral Applied",
      description: "Referral code has been applied to your account!"
    });
    setReferralCode('');
  };

  if (!state.user) return null;

  return (
    <Dialog>
      <DialogTrigger asChild>
        {trigger || (
          <Button variant="outline" size="sm">
            <User className="h-4 w-4 mr-2" />
            Profile
          </Button>
        )}
      </DialogTrigger>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>User Profile</DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="profile" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="profile">Profile</TabsTrigger>
            <TabsTrigger value="referrals">Referrals</TabsTrigger>
            <TabsTrigger value="bets">Bet History</TabsTrigger>
          </TabsList>

          <TabsContent value="profile" className="space-y-6">
          {/* Profile Header */}
          <div className="flex items-center gap-4">
            <Avatar className="h-20 w-20">
              <AvatarImage src={selectedAvatar} />
              <AvatarFallback className="text-lg">
                {state.user.username.slice(0, 2).toUpperCase()}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-2">
                <h3 className="text-xl font-bold">{state.user.username}</h3>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setIsEditing(!isEditing)}
                >
                  <Edit className="h-4 w-4" />
                </Button>
              </div>
              <p className="text-sm text-muted-foreground">
                {state.user.walletAddress.slice(0, 6)}...{state.user.walletAddress.slice(-4)}
              </p>
              <Badge variant="secondary" className="mt-1">
                Balance: {state.user.balance.toFixed(2)} SOL
              </Badge>
            </div>
          </div>

          {/* Edit Form */}
          {isEditing && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Edit Profile</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="username">Username</Label>
                  <Input
                    id="username"
                    value={newUsername}
                    onChange={(e) => setNewUsername(e.target.value)}
                    placeholder="Enter username"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="profilePicture">Profile Picture URL</Label>
                  <Input
                    id="profilePicture"
                    value={selectedAvatar}
                    onChange={(e) => setSelectedAvatar(e.target.value)}
                    placeholder="Enter image URL"
                  />
                  <p className="text-xs text-muted-foreground">
                    Upload your image to an image hosting service and paste the URL here
                  </p>
                </div>

                <div className="flex gap-2">
                  <Button onClick={handleSaveProfile}>
                    Save Changes
                  </Button>
                  <Button variant="outline" onClick={() => setIsEditing(false)}>
                    Cancel
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Card>
              <CardContent className="p-4 text-center">
                <DollarSign className="h-8 w-8 mx-auto mb-2 text-green-500" />
                <div className="text-lg font-bold text-green-600">
                  +{state.user.profit.toFixed(1)}
                </div>
                <div className="text-sm text-muted-foreground">Profit (SOL)</div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4 text-center">
                <Target className="h-8 w-8 mx-auto mb-2 text-blue-500" />
                <div className="text-lg font-bold">
                  {state.user.winRate.toFixed(1)}%
                </div>
                <div className="text-sm text-muted-foreground">Win Rate</div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4 text-center">
                <TrendingUp className="h-8 w-8 mx-auto mb-2 text-purple-500" />
                <div className="text-lg font-bold">
                  {state.user.totalBets}
                </div>
                <div className="text-sm text-muted-foreground">Total Bets</div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4 text-center">
                <Trophy className="h-8 w-8 mx-auto mb-2 text-yellow-500" />
                <div className="text-lg font-bold">
                  #{state.user.rank || 'N/A'}
                </div>
                <div className="text-sm text-muted-foreground">Rank</div>
              </CardContent>
            </Card>
          </div>
          </TabsContent>

          {/* Referrals Tab */}
          <TabsContent value="referrals" className="space-y-6">
            <div className="grid gap-6">
              {/* Referral Stats */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Card>
                  <CardContent className="p-4 text-center">
                    <Users className="h-8 w-8 mx-auto mb-2 text-blue-500" />
                    <div className="text-lg font-bold">{userReferralStats.totalReferrals}</div>
                    <div className="text-sm text-muted-foreground">Total Referrals</div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardContent className="p-4 text-center">
                    <DollarSign className="h-8 w-8 mx-auto mb-2 text-green-500" />
                    <div className="text-lg font-bold">{userReferralStats.totalVolume.toFixed(2)} SOL</div>
                    <div className="text-sm text-muted-foreground">Referral Volume</div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardContent className="p-4 text-center">
                    <TrendingUp className="h-8 w-8 mx-auto mb-2 text-purple-500" />
                    <div className="text-lg font-bold text-green-600">+{userReferralStats.earnings.toFixed(2)} SOL</div>
                    <div className="text-sm text-muted-foreground">Earnings</div>
                  </CardContent>
                </Card>
              </div>

              {/* Your Referral Code */}
              <Card>
                <CardHeader>
                  <CardTitle>Your Referral Code</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label>Referral Code</Label>
                    <div className="flex gap-2">
                      <Input value={userReferralCode} readOnly />
                      <Button variant="outline" size="sm" onClick={copyReferralCode}>
                        <Copy className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <Label>Referral Link</Label>
                    <div className="flex gap-2">
                      <Input value={referralLink} readOnly className="text-xs" />
                      <Button variant="outline" size="sm" onClick={copyReferralLink}>
                        <Share2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                  
                   <p className="text-sm text-muted-foreground">
                     Share your referral code or link to earn 5% of your referrals' betting volume!
                   </p>
                   
                   {state.user?.referredBy && (
                     <div className="p-3 bg-accent/50 rounded-lg">
                       <p className="text-sm">
                         You were referred by: <span className="font-medium">{state.user.referredBy}</span>
                       </p>
                     </div>
                   )}
                </CardContent>
              </Card>

              {/* Apply Referral Code */}
              <Card>
                <CardHeader>
                  <CardTitle>Apply Referral Code</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label>Enter Referral Code</Label>
                    <div className="flex gap-2">
                      <Input
                        value={referralCode}
                        onChange={(e) => setReferralCode(e.target.value)}
                        placeholder="Enter referral code"
                      />
                      <Button onClick={applyReferralCode}>Apply</Button>
                    </div>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Apply a referral code to support another user and get started with a bonus!
                  </p>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Bet History Tab */}
          <TabsContent value="bets" className="space-y-6">
            {/* Recent Bets */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Recent Bets</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {state.bets.slice(-5).reverse().map((bet) => (
                  <div key={bet.id} className="flex justify-between items-center p-2 rounded bg-accent/30">
                    <div className="text-sm">
                      <span className="font-medium">{bet.option.toUpperCase()}</span>
                      {' - '}
                      <span className="text-muted-foreground">
                        {bet.amount} SOL
                      </span>
                    </div>
                    <Badge variant={bet.settled ? 
                      (bet.payout && bet.payout > bet.amount ? 'default' : 'destructive') 
                      : 'secondary'
                    }>
                      {bet.settled 
                        ? (bet.payout && bet.payout > bet.amount ? 'Won' : 'Lost')
                        : 'Pending'
                      }
                    </Badge>
                  </div>
                ))}
                {state.bets.length === 0 && (
                  <p className="text-center text-muted-foreground py-4">
                    No bets placed yet
                  </p>
                )}
              </div>
            </CardContent>
          </Card>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
};