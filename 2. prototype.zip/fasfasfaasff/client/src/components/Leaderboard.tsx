import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Trophy, TrendingUp, Target, Zap } from 'lucide-react';

interface LeaderboardEntry {
  rank: number;
  username: string;
  profit: number;
  winRate: number;
  totalBets: number;
  streak: number;
  volume: number;
}

const mockLeaderboard: LeaderboardEntry[] = [];

export const Leaderboard = () => {
  const [selectedTab, setSelectedTab] = useState('profit');

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1:
        return '🥇';
      case 2:
        return '🥈';
      case 3:
        return '🥉';
      default:
        return rank.toString();
    }
  };

  const getRankBadgeVariant = (rank: number) => {
    if (rank <= 3) return 'default';
    if (rank <= 10) return 'secondary';
    return 'outline';
  };

  const sortedLeaderboard = [...mockLeaderboard].sort((a, b) => {
    switch (selectedTab) {
      case 'profit':
        return b.profit - a.profit;
      case 'winrate':
        return b.winRate - a.winRate;
      case 'volume':
        return b.volume - a.volume;
      case 'streak':
        return b.streak - a.streak;
      default:
        return a.rank - b.rank;
    }
  });

  return (
    <Card className="h-full">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2">
          <Trophy className="h-5 w-5 text-yellow-500" />
          Leaderboard
        </CardTitle>
      </CardHeader>

      <CardContent className="space-y-4">
        <Tabs value={selectedTab} onValueChange={setSelectedTab}>
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="profit" className="text-xs">
              <TrendingUp className="h-3 w-3 mr-1" />
              Profit
            </TabsTrigger>
            <TabsTrigger value="winrate" className="text-xs">
              <Target className="h-3 w-3 mr-1" />
              Win %
            </TabsTrigger>
            <TabsTrigger value="volume" className="text-xs">
              Volume
            </TabsTrigger>
            <TabsTrigger value="streak" className="text-xs">
              <Zap className="h-3 w-3 mr-1" />
              Streak
            </TabsTrigger>
          </TabsList>

          <TabsContent value={selectedTab} className="mt-4">
            <div className="space-y-2 max-h-64 overflow-y-auto">
              {sortedLeaderboard.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  No users yet. Be the first to place a bet!
                </div>
              ) : (
                sortedLeaderboard.map((entry, index) => (
                  <div
                    key={entry.username}
                    className="flex items-center gap-3 p-3 rounded-lg bg-accent/30 hover:bg-accent/50 transition-colors"
                  >
                    {/* Rank */}
                    <div className="flex items-center justify-center w-8 h-8">
                      {entry.rank <= 3 ? (
                        <span className="text-lg">{getRankIcon(entry.rank)}</span>
                      ) : (
                        <Badge variant={getRankBadgeVariant(entry.rank)} className="w-6 h-6 p-0 text-xs">
                          {entry.rank}
                        </Badge>
                      )}
                    </div>

                    {/* Avatar */}
                    <Avatar className="h-8 w-8">
                      <AvatarFallback className="text-xs">
                        {entry.username.slice(0, 2).toUpperCase()}
                      </AvatarFallback>
                    </Avatar>

                    {/* User Info */}
                    <div className="flex-1 min-w-0">
                      <div className="font-medium text-sm truncate">
                        {entry.username}
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {entry.totalBets} bets
                      </div>
                    </div>

                    {/* Stats */}
                    <div className="text-right">
                      {selectedTab === 'profit' && (
                        <>
                          <div className="font-medium text-sm text-green-600 dark:text-green-400">
                            +{entry.profit.toFixed(1)} SOL
                          </div>
                          <div className="text-xs text-muted-foreground">
                            {entry.winRate.toFixed(1)}% win
                          </div>
                        </>
                      )}
                      
                      {selectedTab === 'winrate' && (
                        <>
                          <div className="font-medium text-sm">
                            {entry.winRate.toFixed(1)}%
                          </div>
                          <div className="text-xs text-muted-foreground">
                            {entry.totalBets} bets
                          </div>
                        </>
                      )}
                      
                      {selectedTab === 'volume' && (
                        <>
                          <div className="font-medium text-sm">
                            {entry.volume.toFixed(0)} SOL
                          </div>
                          <div className="text-xs text-muted-foreground">
                            volume
                          </div>
                        </>
                      )}
                      
                      {selectedTab === 'streak' && (
                        <>
                          <div className="font-medium text-sm flex items-center gap-1">
                            <Zap className="h-3 w-3 text-yellow-500" />
                            {entry.streak}
                          </div>
                          <div className="text-xs text-muted-foreground">
                            wins
                          </div>
                        </>
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
};