import { Button } from '@/components/ui/button';
import { Wallet } from 'lucide-react';
import { Link } from 'wouter';
import { useApp } from '@/contexts/AppContext';

const LeaderboardPage = () => {
  const { state } = useApp();

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="flex items-center justify-between p-6 border-b border-border">
        <div className="flex items-center gap-2">
          <Link href="/">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center cursor-pointer">
              <span className="text-primary-foreground font-bold text-sm">S</span>
            </div>
          </Link>
          <Link href="/">
            <span className="text-xl font-bold cursor-pointer">SolanaPredict</span>
          </Link>
        </div>
        <div className="flex items-center gap-6">
          <Link href="/">
            <span className="text-muted-foreground hover:text-foreground cursor-pointer">Markets</span>
          </Link>
          <span className="text-foreground font-medium">Leaderboard</span>
          <Button className="bg-primary hover:bg-primary/90">
            Connect Wallet
          </Button>
        </div>
      </nav>

      {/* Main Content */}
      <div className="container mx-auto p-6">
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2 gradient-text">Top Predictors</h1>
        </div>

        {/* Leaderboard Table */}
        <div className="bg-card border border-border rounded-xl overflow-hidden">
          <div className="bg-secondary/50 border-b border-border">
            <div className="grid grid-cols-5 gap-4 p-4 text-sm font-medium text-muted-foreground">
              <div>Rank</div>
              <div>User</div>
              <div>Predictions</div>
              <div>Win Rate</div>
              <div>Total Wagered</div>
            </div>
          </div>

          {/* Leaderboard Data */}
          <div className="divide-y divide-border">
            {state.profiles.length > 0 ? (
              state.profiles.slice(0, 10).map((profile, index) => (
                <div key={profile.id} className="grid grid-cols-5 gap-4 p-4 hover:bg-secondary/30 transition-colors">
                  <div className="flex items-center gap-2">
                    <span className="text-lg font-semibold">#{index + 1}</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 bg-gradient-to-br from-primary to-accent rounded-full flex items-center justify-center">
                      <span className="text-xs font-bold text-white">
                        {profile.username?.charAt(0).toUpperCase() || 'U'}
                      </span>
                    </div>
                    <span className="font-medium">{profile.username || 'Anonymous'}</span>
                  </div>
                  <div className="flex items-center">
                    <span className="font-medium">{profile.totalBets || 0}</span>
                  </div>
                  <div className="flex items-center">
                    <span className="font-medium">
                      {profile.totalBets ? 
                        Math.round(((profile.successfulBets || 0) / profile.totalBets) * 100) : 0
                      }%
                    </span>
                  </div>
                  <div className="flex items-center">
                    <span className="font-medium">{profile.totalWagered || 0} SOL</span>
                  </div>
                </div>
              ))
            ) : (
              <div className="p-8 text-center text-muted-foreground">
                <p>No predictors found</p>
              </div>
            )}
          </div>
        </div>

        {/* Empty State for when there are no users */}
        {state.profiles.length === 0 && (
          <div className="text-center py-16">
            <div className="text-muted-foreground text-lg mb-4">
              No leaderboard data available yet.
            </div>
            <p className="text-muted-foreground mb-6">
              Start making predictions to appear on the leaderboard!
            </p>
            <Link href="/">
              <Button className="bg-primary hover:bg-primary/90">
                Explore Markets
              </Button>
            </Link>
          </div>
        )}
      </div>
    </div>
  );
};

export default LeaderboardPage;