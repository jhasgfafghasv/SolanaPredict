import { WalletConnect } from '@/components/WalletConnect';
import { UserProfile } from '@/components/UserProfile';
import { AdminPortal } from '@/components/AdminPortal';
import { PredictionMarket } from '@/components/PredictionMarket';
import { Leaderboard } from '@/components/Leaderboard';
import { LiveChat } from '@/components/LiveChat';
import { WalletActions } from '@/components/WalletActions';
import { Button } from '@/components/ui/button';
import { Wallet } from 'lucide-react';
import { useSolanaWallet } from '@/hooks/useSolanaWallet';
import { useCreateProfile, useProfileByWallet } from '@/hooks/useProfiles';
import { useApp } from '@/contexts/AppContext';

const Index = () => {
  const { state, dispatch } = useApp();
  const { connectWallet, isConnecting } = useSolanaWallet();
  const createProfile = useCreateProfile();

  const handleConnect = async () => {
    try {
      const wallet = await connectWallet();
      
      // Check if profile exists in database
      const existingProfile = await fetch(`/api/profiles/wallet/${wallet.address}`)
        .then(res => res.ok ? res.json() : null)
        .catch(() => null);

      let profile;
      if (existingProfile) {
        profile = existingProfile;
      } else {
        // Create new profile in database
        const newProfileData = {
          walletAddress: wallet.address,
          username: `User${wallet.address.slice(-4)}`,
          balance: wallet.balance.toString(),
          totalVolume: "0",
          totalBets: 0,
          winRate: "0",
        };
        
        profile = await createProfile.mutateAsync(newProfileData);
      }
      
      dispatch({ type: 'CONNECT_WALLET', payload: profile });
    } catch (error) {
      console.error('Connection failed:', error);
    }
  };

  if (!state.isWalletConnected) {
    return (
      <div className="min-h-screen bg-background">
        {/* Navigation */}
        <nav className="flex items-center justify-between p-6">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
              <span className="text-primary-foreground font-bold text-sm">S</span>
            </div>
            <span className="text-xl font-bold">SolanaPredict</span>
          </div>
          <div className="flex items-center gap-6">
            <Button 
              onClick={handleConnect}
              disabled={isConnecting}
              className="bg-primary hover:bg-primary/90"
            >
              {isConnecting ? 'Connecting...' : 'Connect Wallet'}
            </Button>
          </div>
        </nav>

        {/* Hero Section */}
        <div className="flex flex-col items-center justify-center min-h-[80vh] px-6">
          <div className="text-center max-w-4xl mx-auto">
            <h1 className="text-6xl md:text-7xl font-bold mb-6">
              <span className="gradient-text">Predict the Future</span>
              <br />
              <span className="text-foreground">on the Solana Blockchain</span>
            </h1>
            <p className="text-xl text-muted-foreground mb-12 max-w-2xl mx-auto leading-relaxed">
              Engage in decentralized prediction markets with lightning-fast transactions
              and low fees. Your insight is your asset.
            </p>

            {/* Wallet Connection Card */}
            <div className="glass-card rounded-2xl p-8 max-w-md mx-auto hover-glow">
              <div className="flex items-center justify-center mb-4">
                <Wallet className="h-8 w-8 text-muted-foreground" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Connect Your Wallet</h3>
              <p className="text-muted-foreground mb-6 text-sm">
                Connect your Solana wallet to start predicting
              </p>
              <div className="w-full">
                <WalletConnect />
              </div>
              <p className="text-xs text-muted-foreground mt-4">
                Supports Phantom, Solflare, and more.
              </p>
            </div>
          </div>

          {/* Why Choose Section */}
          <div className="mt-24 text-center">
            <h2 className="text-3xl font-bold text-foreground mb-8">Why Choose SolanaPredict?</h2>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="flex items-center justify-between p-6 border-b border-border">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
            <span className="text-primary-foreground font-bold text-sm">S</span>
          </div>
          <span className="text-xl font-bold">SolanaPredict</span>
        </div>
        <div className="flex items-center gap-4">
          <WalletActions />
          <AdminPortal />
          <UserProfile 
            trigger={
              <Button variant="outline" size="sm">
                <Wallet className="h-4 w-4 mr-2" />
                {state.user?.username || 'Wallet'}
              </Button>
            }
          />
          <Button 
            variant="ghost" 
            size="sm"
            onClick={() => dispatch({ type: 'DISCONNECT_WALLET' })}
            className="text-muted-foreground hover:text-foreground"
          >
            Disconnect
          </Button>
        </div>
      </nav>

      {/* Main Content */}
      <div className="container mx-auto p-6">
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2">Prediction Markets</h1>
          <p className="text-muted-foreground">
            Discover and participate in the most exciting prediction markets on Solana
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="bg-card border border-border rounded-xl p-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-muted-foreground text-sm">Total Markets</span>
              <div className="text-primary">📈</div>
            </div>
            <div className="text-2xl font-bold">{state.predictions.length}</div>
          </div>
          
          <div className="bg-card border border-border rounded-xl p-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-muted-foreground text-sm">Active Markets</span>
              <div className="text-green-500">🟢</div>
            </div>
            <div className="text-2xl font-bold">{state.predictions.filter(p => p.status === 'active').length}</div>
          </div>
          
          <div className="bg-card border border-border rounded-xl p-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-muted-foreground text-sm">Total Volume</span>
              <div className="text-blue-500">📊</div>
            </div>
            <div className="text-2xl font-bold">0.0 SOL</div>
          </div>
          
          <div className="bg-card border border-border rounded-xl p-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-muted-foreground text-sm">Total Predictions</span>
              <div className="text-yellow-500">🏆</div>
            </div>
            <div className="text-2xl font-bold">{state.bets.length}</div>
          </div>
        </div>

        {/* Filter Bar */}
        <div className="bg-card border border-border rounded-xl p-4 mb-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="relative">
                <input
                  type="text"
                  placeholder="Search predictions..."
                  className="bg-background border border-border rounded-lg px-4 py-2 pr-10 w-64"
                />
              </div>
              <div className="flex gap-2">
                <button className="category-pill category-all">All</button>
                <button className="category-pill category-crypto">Crypto</button>
                <button className="category-pill category-sports">Sports</button>
                <button className="category-pill category-finance">Finance</button>
                <button className="category-pill category-stocks">Stocks</button>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-muted-foreground text-sm">Trending</span>
              <button className="text-muted-foreground">⚙️</button>
            </div>
          </div>
        </div>

        {/* Content Area */}
        {state.predictions.length > 0 ? (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <PredictionMarket />
            </div>
            <div className="space-y-6">
              <Leaderboard />
            </div>
          </div>
        ) : (
          <div className="text-center py-16">
            <div className="text-muted-foreground text-lg mb-2">
              No predictions found matching your criteria.
            </div>
          </div>
        )}
      </div>
      
      {/* Live Chat */}
      <LiveChat />
    </div>
  );
};

export default Index;
