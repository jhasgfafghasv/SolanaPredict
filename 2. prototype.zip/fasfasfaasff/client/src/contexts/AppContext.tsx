import React, { createContext, useContext, useReducer, ReactNode } from 'react';

interface User {
  walletAddress: string;
  balance: number;
  username: string;
  totalBets: number;
  profit: number;
  winRate: number;
  profilePicture?: string;
  rank?: number;
  referralCode?: string;
  referredBy?: string;
}

interface Bet {
  id: string;
  predictionId: string;
  userId: string;
  option: 'yes' | 'no';
  amount: number;
  timestamp: Date;
  settled?: boolean;
  payout?: number;
}

interface Prediction {
  id: string;
  question: string;
  category: string;
  endTime: Date;
  totalPool: number;
  yesPool: number;
  noPool: number;
  participants: number;
  status: 'active' | 'ended' | 'resolved';
  result?: 'yes' | 'no';
}

interface ReferralStats {
  totalReferrals: number;
  totalVolume: number;
  earnings: number;
}

interface AppState {
  user: User | null;
  isWalletConnected: boolean;
  bets: Bet[];
  messages: any[];
  leaderboard: any[];
  predictions: Prediction[];
  referralStats: { [walletAddress: string]: ReferralStats };
}

type AppAction =
  | { type: 'CONNECT_WALLET'; payload: User }
  | { type: 'DISCONNECT_WALLET' }
  | { type: 'PLACE_BET'; payload: Bet }
  | { type: 'ADD_MESSAGE'; payload: any }
  | { type: 'UPDATE_LEADERBOARD'; payload: any[] }
  | { type: 'UPDATE_BALANCE'; payload: number }
  | { type: 'UPDATE_USER_PROFILE'; payload: { username: string; profilePicture: string } }
  | { type: 'APPLY_HOUSE_EDGE'; payload: { amount: number; percentage: number } }
  | { type: 'ADD_PREDICTION'; payload: Prediction }
  | { type: 'DELETE_PREDICTION'; payload: string }
  | { type: 'RESOLVE_PREDICTION'; payload: { id: string; result: 'yes' | 'no' } }
  | { type: 'UPDATE_PREDICTION_POOLS'; payload: { id: string; yesPool: number; noPool: number; participants: number } }
  | { type: 'UPDATE_REFERRAL_STATS'; payload: { walletAddress: string; stats: ReferralStats } }
  | { type: 'APPLY_REFERRAL_CODE'; payload: { walletAddress: string; referralCode: string } };

const initialState: AppState = {
  user: null,
  isWalletConnected: false,
  bets: [],
  messages: [],
  leaderboard: [],
  predictions: [],
  referralStats: {}
};

const AppContext = createContext<{
  state: AppState;
  dispatch: React.Dispatch<AppAction>;
} | null>(null);

function appReducer(state: AppState, action: AppAction): AppState {
  switch (action.type) {
    case 'CONNECT_WALLET':
      return {
        ...state,
        user: action.payload,
        isWalletConnected: true
      };
    case 'DISCONNECT_WALLET':
      return {
        ...state,
        user: null,
        isWalletConnected: false
      };
    case 'PLACE_BET':
      return {
        ...state,
        bets: [...state.bets, action.payload]
      };
    case 'ADD_MESSAGE':
      return {
        ...state,
        messages: [...state.messages, action.payload].slice(-50)
      };
    case 'UPDATE_LEADERBOARD':
      return {
        ...state,
        leaderboard: action.payload
      };
    case 'UPDATE_BALANCE':
      return {
        ...state,
        user: state.user ? { ...state.user, balance: action.payload } : null
      };
    case 'UPDATE_USER_PROFILE':
      return {
        ...state,
        user: state.user ? { 
          ...state.user, 
          username: action.payload.username,
          profilePicture: action.payload.profilePicture
        } : null
      };
    case 'APPLY_HOUSE_EDGE':
      // House takes percentage of losing bets
      return {
        ...state,
        messages: [...state.messages, {
          id: Date.now().toString(),
          username: 'System',
          message: `House edge applied: ${action.payload.amount.toFixed(2)} SOL (${action.payload.percentage}%)`,
          timestamp: new Date(),
          type: 'system'
        }].slice(-50)
      };
    case 'ADD_PREDICTION':
      return {
        ...state,
        predictions: [...state.predictions, action.payload]
      };
    case 'DELETE_PREDICTION':
      return {
        ...state,
        predictions: state.predictions.filter(p => p.id !== action.payload)
      };
    case 'RESOLVE_PREDICTION':
      return {
        ...state,
        predictions: state.predictions.map(p => 
          p.id === action.payload.id 
            ? { ...p, status: 'resolved' as const, result: action.payload.result }
            : p
        )
      };
    case 'UPDATE_PREDICTION_POOLS':
      return {
        ...state,
        predictions: state.predictions.map(p => 
          p.id === action.payload.id 
            ? { 
                ...p, 
                yesPool: action.payload.yesPool,
                noPool: action.payload.noPool,
                participants: action.payload.participants,
                totalPool: action.payload.yesPool + action.payload.noPool
              }
            : p
        )
      };
    case 'UPDATE_REFERRAL_STATS':
      return {
        ...state,
        referralStats: {
          ...state.referralStats,
          [action.payload.walletAddress]: action.payload.stats
        }
      };
    case 'APPLY_REFERRAL_CODE':
      return {
        ...state,
        user: state.user ? {
          ...state.user,
          referredBy: action.payload.referralCode
        } : null
      };
    default:
      return state;
  }
}

export const AppProvider = ({ children }: { children: ReactNode }) => {
  const [state, dispatch] = useReducer(appReducer, initialState);

  return (
    <AppContext.Provider value={{ state, dispatch }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within AppProvider');
  }
  return context;
};