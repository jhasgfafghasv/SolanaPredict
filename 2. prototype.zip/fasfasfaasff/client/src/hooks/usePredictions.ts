import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { Prediction, InsertPrediction } from "@shared/schema";

export const usePredictions = () => {
  return useQuery<Prediction[]>({
    queryKey: ["/api/predictions"],
    queryFn: () => fetch("/api/predictions").then(res => res.json()),
  });
};

export const usePrediction = (id: string) => {
  return useQuery<Prediction>({
    queryKey: ["/api/predictions", id],
    queryFn: () => fetch(`/api/predictions/${id}`).then(res => res.json()),
    enabled: !!id,
  });
};

export const useCreatePrediction = () => {
  return useMutation({
    mutationFn: async (predictionData: InsertPrediction) => {
      return apiRequest("/api/predictions", {
        method: "POST",
        body: JSON.stringify(predictionData),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/predictions"] });
    },
  });
};

export const useUpdatePrediction = () => {
  return useMutation({
    mutationFn: async ({ id, updates }: { id: string; updates: Partial<InsertPrediction> }) => {
      return apiRequest(`/api/predictions/${id}`, {
        method: "PATCH",
        body: JSON.stringify(updates),
      });
    },
    onSuccess: (data, { id }) => {
      queryClient.invalidateQueries({ queryKey: ["/api/predictions"] });
      queryClient.invalidateQueries({ queryKey: ["/api/predictions", id] });
    },
  });
};

export const useDeletePrediction = () => {
  return useMutation({
    mutationFn: async (id: string) => {
      return apiRequest(`/api/predictions/${id}`, {
        method: "DELETE",
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/predictions"] });
    },
  });
};