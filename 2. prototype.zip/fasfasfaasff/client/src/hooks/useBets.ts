import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { Bet, InsertBet } from "@shared/schema";

export const useBets = () => {
  return useQuery<Bet[]>({
    queryKey: ["/api/bets"],
    queryFn: () => fetch("/api/bets").then(res => res.json()),
  });
};

export const useBetsByUser = (userId: string) => {
  return useQuery<Bet[]>({
    queryKey: ["/api/bets/user", userId],
    queryFn: () => fetch(`/api/bets/user/${userId}`).then(res => res.json()),
    enabled: !!userId,
  });
};

export const useBetsByPrediction = (predictionId: string) => {
  return useQuery<Bet[]>({
    queryKey: ["/api/bets/prediction", predictionId],
    queryFn: () => fetch(`/api/bets/prediction/${predictionId}`).then(res => res.json()),
    enabled: !!predictionId,
  });
};

export const useCreateBet = () => {
  return useMutation({
    mutationFn: async (betData: InsertBet) => {
      return apiRequest("/api/bets", {
        method: "POST",
        body: JSON.stringify(betData),
      });
    },
    onSuccess: (data, variables) => {
      queryClient.invalidateQueries({ queryKey: ["/api/bets"] });
      queryClient.invalidateQueries({ queryKey: ["/api/bets/user", variables.userId] });
      queryClient.invalidateQueries({ queryKey: ["/api/bets/prediction", variables.predictionId] });
      queryClient.invalidateQueries({ queryKey: ["/api/predictions"] });
      queryClient.invalidateQueries({ queryKey: ["/api/predictions", variables.predictionId] });
    },
  });
};