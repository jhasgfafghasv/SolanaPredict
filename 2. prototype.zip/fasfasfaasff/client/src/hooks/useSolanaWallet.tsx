import { useState, useCallback } from 'react';
import { Connection, PublicKey, LAMPORTS_PER_SOL } from '@solana/web3.js';
import { useToast } from '@/hooks/use-toast';

// For demo purposes - in production, use @solana/wallet-adapter
const SOLANA_NETWORK = 'https://api.devnet.solana.com';

export const useSolanaWallet = () => {
  const [isConnecting, setIsConnecting] = useState(false);
  const { toast } = useToast();

  const connectWallet = useCallback(async () => {
    setIsConnecting(true);
    
    try {
      // Check if Phantom wallet is available
      const isPhantomInstalled = window.solana && window.solana.isPhantom;
      
      if (!isPhantomInstalled) {
        throw new Error('No Solana wallet detected. Please install Phantom, Solflare, or Backpack wallet.');
      }

      // Real Phantom wallet connection
      const response = await window.solana.connect();
      const publicKey = response.publicKey.toString();
      
      // Get balance
      const connection = new Connection(SOLANA_NETWORK);
      const balance = await connection.getBalance(new PublicKey(publicKey));
      const solBalance = balance / LAMPORTS_PER_SOL;
      
      toast({
        title: "Wallet Connected",
        description: "Successfully connected to Phantom wallet",
      });
      
      return {
        address: publicKey,
        balance: solBalance,
        isDemo: false
      };
      
    } catch (error) {
      console.error('Wallet connection failed:', error);
      toast({
        title: "Connection Failed",
        description: error instanceof Error ? error.message : "Failed to connect wallet",
        variant: "destructive"
      });
      
      throw error;
    } finally {
      setIsConnecting(false);
    }
  }, [toast]);

  const disconnectWallet = useCallback(async () => {
    try {
      if (window.solana && window.solana.isPhantom) {
        await window.solana.disconnect();
      }
      
      toast({
        title: "Wallet Disconnected",
        description: "Your wallet has been disconnected",
      });
    } catch (error) {
      console.error('Disconnect failed:', error);
    }
  }, [toast]);

  const sendTransaction = useCallback(async (amount: number, recipient?: string) => {
    try {
      // Mock transaction for demo
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      toast({
        title: "Transaction Successful",
        description: `Sent ${amount} SOL`,
      });
      
      return {
        signature: 'mock_signature_' + Date.now(),
        success: true
      };
    } catch (error) {
      toast({
        title: "Transaction Failed",
        description: "Failed to send transaction",
        variant: "destructive"
      });
      
      return {
        signature: null,
        success: false
      };
    }
  }, [toast]);

  return {
    connectWallet,
    disconnectWallet,
    sendTransaction,
    isConnecting
  };
};

const generateMockAddress = () => {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let result = '';
  for (let i = 0; i < 44; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
};

// Extend Window interface for Phantom wallet
declare global {
  interface Window {
    solana?: {
      isPhantom?: boolean;
      connect: () => Promise<{ publicKey: { toString: () => string } }>;
      disconnect: () => Promise<void>;
    };
  }
}