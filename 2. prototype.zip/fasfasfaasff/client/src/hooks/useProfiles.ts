import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { Profile, InsertProfile } from "@shared/schema";

export const useProfiles = () => {
  return useQuery<Profile[]>({
    queryKey: ["/api/profiles"],
    queryFn: () => fetch("/api/profiles").then(res => res.json()),
  });
};

export const useProfile = (id: string) => {
  return useQuery<Profile>({
    queryKey: ["/api/profiles", id],
    queryFn: () => fetch(`/api/profiles/${id}`).then(res => res.json()),
    enabled: !!id,
  });
};

export const useProfileByWallet = (walletAddress: string) => {
  return useQuery<Profile>({
    queryKey: ["/api/profiles/wallet", walletAddress],
    queryFn: () => fetch(`/api/profiles/wallet/${walletAddress}`).then(res => res.json()),
    enabled: !!walletAddress,
  });
};

export const useCreateProfile = () => {
  return useMutation({
    mutationFn: async (profileData: InsertProfile) => {
      return apiRequest("/api/profiles", {
        method: "POST",
        body: JSON.stringify(profileData),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/profiles"] });
    },
  });
};

export const useUpdateProfile = () => {
  return useMutation({
    mutationFn: async ({ id, updates }: { id: string; updates: Partial<InsertProfile> }) => {
      return apiRequest(`/api/profiles/${id}`, {
        method: "PATCH",
        body: JSON.stringify(updates),
      });
    },
    onSuccess: (data, { id }) => {
      queryClient.invalidateQueries({ queryKey: ["/api/profiles"] });
      queryClient.invalidateQueries({ queryKey: ["/api/profiles", id] });
    },
  });
};