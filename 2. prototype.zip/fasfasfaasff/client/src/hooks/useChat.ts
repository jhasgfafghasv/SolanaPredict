import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { ChatMessage, InsertChatMessage } from "@shared/schema";

export const useChatMessages = () => {
  return useQuery<ChatMessage[]>({
    queryKey: ["/api/chat/messages"],
    queryFn: () => fetch("/api/chat/messages").then(res => res.json()),
    refetchInterval: 3000, // Poll every 3 seconds for new messages
  });
};

export const useCreateChatMessage = () => {
  return useMutation({
    mutationFn: async (messageData: InsertChatMessage) => {
      return apiRequest("/api/chat/messages", {
        method: "POST",
        body: JSON.stringify(messageData),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/chat/messages"] });
    },
  });
};