# SolanaPredict - Prediction Market Platform

## Project Overview
A Solana-based prediction market platform where users can connect their wallets, place bets on future events, and participate in community discussions. Successfully migrated from Lovable to Replit environment with full PostgreSQL database integration.

## Architecture
- **Frontend**: React + TypeScript with Vite
- **Backend**: Express.js with TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **Routing**: Wouter for client-side routing
- **State Management**: React Context API + TanStack Query
- **UI Framework**: Shadcn/ui with Tailwind CSS
- **Wallet Integration**: Solana Web3.js for Phantom wallet connection

## Recent Changes (January 2025)
- ✅ Migrated from Supabase to PostgreSQL with Drizzle ORM
- ✅ Replaced React Router with Wouter
- ✅ Created comprehensive API routes for all data operations
- ✅ Implemented database schema with proper relationships
- ✅ Set up React Query hooks for API integration
- ✅ Removed all Supabase dependencies
- ✅ Established client/server separation for security
- ✅ Updated design to match provided screenshots with dark theme
- ✅ Fixed wallet connection functionality and removed duplicates
- ✅ Added floating live chat component with modern UI
- ✅ Implemented proper navigation without Markets/Leaderboard tabs
- ✅ Positioned leaderboard under prediction markets as requested

## Key Features
1. **Wallet Connection**: Phantom wallet integration for Solana
2. **Prediction Markets**: Create and participate in betting markets
3. **Real-time Chat**: Community discussion system
4. **Admin Portal**: Administrative controls for market management
5. **Leaderboard**: User ranking and statistics
6. **Referral System**: User referral tracking and rewards

## Database Schema
- **profiles**: User profiles with wallet addresses and stats
- **predictions**: Prediction markets with pools and status
- **bets**: Individual user bets on predictions
- **transactions**: Financial transaction history
- **chat_messages**: Real-time chat system
- **admin_settings**: Configuration settings
- **referral_stats**: Referral tracking data

## API Endpoints
- `/api/profiles` - User profile management
- `/api/predictions` - Prediction market operations
- `/api/bets` - Betting functionality
- `/api/transactions` - Transaction history
- `/api/chat/messages` - Chat system
- `/api/admin/settings` - Admin configuration
- `/api/referrals` - Referral system

## Development Setup
1. Database is automatically provisioned with PostgreSQL
2. Schema is managed through Drizzle migrations
3. Run `npm run dev` to start the development server
4. Database schema updates via `npm run db:push`

## Security Considerations
- Client/server separation properly implemented
- Database credentials secured in environment variables
- API validation using Zod schemas
- PostgreSQL RLS policies implemented in schema

## User Preferences
- Project successfully migrated from Lovable to Replit
- Full-stack JavaScript application with modern practices
- Clean architecture with separation of concerns
- Comprehensive error handling and validation

## Next Steps
- Application is ready for development and testing
- All core functionality has been migrated and integrated
- Database schema is deployed and ready
- API endpoints are functional and documented