import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertProfileSchema, insertPredictionSchema, insertBetSchema, insertTransactionSchema, insertChatMessageSchema, insertAdminSettingSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Profile/User routes
  app.get("/api/profiles", async (req, res) => {
    try {
      const profiles = await storage.getAllProfiles();
      res.json(profiles);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch profiles" });
    }
  });

  app.get("/api/profiles/:id", async (req, res) => {
    try {
      const profile = await storage.getProfile(req.params.id);
      if (!profile) {
        return res.status(404).json({ error: "Profile not found" });
      }
      res.json(profile);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch profile" });
    }
  });

  app.get("/api/profiles/wallet/:address", async (req, res) => {
    try {
      const profile = await storage.getProfileByWallet(req.params.address);
      if (!profile) {
        return res.status(404).json({ error: "Profile not found" });
      }
      res.json(profile);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch profile" });
    }
  });

  app.post("/api/profiles", async (req, res) => {
    try {
      const profileData = insertProfileSchema.parse(req.body);
      
      // Check if wallet already exists
      const existing = await storage.getProfileByWallet(profileData.walletAddress);
      if (existing) {
        return res.status(409).json({ error: "Profile with this wallet address already exists" });
      }

      // Generate referral code if not provided
      if (!profileData.referralCode) {
        profileData.referralCode = Math.random().toString(36).substring(2, 10).toUpperCase();
      }

      const profile = await storage.createProfile(profileData);
      res.status(201).json(profile);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid profile data", details: error.errors });
      }
      res.status(500).json({ error: "Failed to create profile" });
    }
  });

  app.patch("/api/profiles/:id", async (req, res) => {
    try {
      const updates = req.body;
      const profile = await storage.updateProfile(req.params.id, updates);
      if (!profile) {
        return res.status(404).json({ error: "Profile not found" });
      }
      res.json(profile);
    } catch (error) {
      res.status(500).json({ error: "Failed to update profile" });
    }
  });

  // Prediction routes
  app.get("/api/predictions", async (req, res) => {
    try {
      const predictions = await storage.getAllPredictions();
      res.json(predictions);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch predictions" });
    }
  });

  app.get("/api/predictions/:id", async (req, res) => {
    try {
      const prediction = await storage.getPrediction(req.params.id);
      if (!prediction) {
        return res.status(404).json({ error: "Prediction not found" });
      }
      res.json(prediction);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch prediction" });
    }
  });

  app.post("/api/predictions", async (req, res) => {
    try {
      const predictionData = insertPredictionSchema.parse(req.body);
      const prediction = await storage.createPrediction(predictionData);
      res.status(201).json(prediction);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid prediction data", details: error.errors });
      }
      res.status(500).json({ error: "Failed to create prediction" });
    }
  });

  app.patch("/api/predictions/:id", async (req, res) => {
    try {
      const updates = req.body;
      const prediction = await storage.updatePrediction(req.params.id, updates);
      if (!prediction) {
        return res.status(404).json({ error: "Prediction not found" });
      }
      res.json(prediction);
    } catch (error) {
      res.status(500).json({ error: "Failed to update prediction" });
    }
  });

  app.delete("/api/predictions/:id", async (req, res) => {
    try {
      const success = await storage.deletePrediction(req.params.id);
      if (!success) {
        return res.status(404).json({ error: "Prediction not found" });
      }
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete prediction" });
    }
  });

  // Bet routes
  app.get("/api/bets", async (req, res) => {
    try {
      const bets = await storage.getAllBets();
      res.json(bets);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch bets" });
    }
  });

  app.get("/api/bets/user/:userId", async (req, res) => {
    try {
      const bets = await storage.getBetsByUser(req.params.userId);
      res.json(bets);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch user bets" });
    }
  });

  app.get("/api/bets/prediction/:predictionId", async (req, res) => {
    try {
      const bets = await storage.getBetsByPrediction(req.params.predictionId);
      res.json(bets);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch prediction bets" });
    }
  });

  app.post("/api/bets", async (req, res) => {
    try {
      const betData = insertBetSchema.parse(req.body);
      
      // Calculate potential payout if not provided
      if (!betData.potentialPayout) {
        const prediction = await storage.getPrediction(betData.predictionId);
        if (prediction) {
          const totalPool = parseFloat(prediction.yesPool) + parseFloat(prediction.noPool);
          const oppositePool = betData.position 
            ? parseFloat(prediction.noPool) 
            : parseFloat(prediction.yesPool);
          
          if (totalPool > 0) {
            betData.potentialPayout = ((parseFloat(betData.amount) * totalPool) / (oppositePool + parseFloat(betData.amount))).toString();
          }
        }
      }

      const bet = await storage.createBet(betData);
      
      // Update prediction pools
      const prediction = await storage.getPrediction(betData.predictionId);
      if (prediction) {
        const updatedPools = {
          yesPool: betData.position 
            ? (parseFloat(prediction.yesPool) + parseFloat(betData.amount)).toString()
            : prediction.yesPool,
          noPool: !betData.position 
            ? (parseFloat(prediction.noPool) + parseFloat(betData.amount)).toString()
            : prediction.noPool,
          participants: prediction.participants + 1
        };
        await storage.updatePrediction(betData.predictionId, updatedPools);
      }

      res.status(201).json(bet);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid bet data", details: error.errors });
      }
      res.status(500).json({ error: "Failed to create bet" });
    }
  });

  // Transaction routes
  app.get("/api/transactions/user/:userId", async (req, res) => {
    try {
      const transactions = await storage.getTransactionsByUser(req.params.userId);
      res.json(transactions);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch transactions" });
    }
  });

  app.post("/api/transactions", async (req, res) => {
    try {
      const transactionData = insertTransactionSchema.parse(req.body);
      const transaction = await storage.createTransaction(transactionData);
      res.status(201).json(transaction);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid transaction data", details: error.errors });
      }
      res.status(500).json({ error: "Failed to create transaction" });
    }
  });

  // Chat routes
  app.get("/api/chat/messages", async (req, res) => {
    try {
      const messages = await storage.getAllChatMessages();
      res.json(messages);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch chat messages" });
    }
  });

  app.post("/api/chat/messages", async (req, res) => {
    try {
      const messageData = insertChatMessageSchema.parse(req.body);
      const message = await storage.createChatMessage(messageData);
      res.status(201).json(message);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid message data", details: error.errors });
      }
      res.status(500).json({ error: "Failed to create message" });
    }
  });

  // Admin settings routes
  app.get("/api/admin/settings", async (req, res) => {
    try {
      const settings = await storage.getAllAdminSettings();
      res.json(settings);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch admin settings" });
    }
  });

  app.get("/api/admin/settings/:key", async (req, res) => {
    try {
      const setting = await storage.getAdminSetting(req.params.key);
      if (!setting) {
        return res.status(404).json({ error: "Setting not found" });
      }
      res.json(setting);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch setting" });
    }
  });

  app.post("/api/admin/settings", async (req, res) => {
    try {
      const settingData = insertAdminSettingSchema.parse(req.body);
      const setting = await storage.setAdminSetting(settingData);
      res.status(201).json(setting);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid setting data", details: error.errors });
      }
      res.status(500).json({ error: "Failed to set admin setting" });
    }
  });

  // Referral stats routes
  app.get("/api/referrals/:userId", async (req, res) => {
    try {
      const stats = await storage.getReferralStats(req.params.userId);
      if (!stats) {
        return res.status(404).json({ error: "Referral stats not found" });
      }
      res.json(stats);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch referral stats" });
    }
  });

  app.patch("/api/referrals/:userId", async (req, res) => {
    try {
      const updates = req.body;
      const stats = await storage.updateReferralStats(req.params.userId, updates);
      res.json(stats);
    } catch (error) {
      res.status(500).json({ error: "Failed to update referral stats" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
