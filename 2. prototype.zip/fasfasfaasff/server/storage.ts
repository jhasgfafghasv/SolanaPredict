import { eq, desc } from "drizzle-orm";
import { drizzle } from "drizzle-orm/node-postgres";
import { Pool } from "pg";
import {
  profiles,
  predictions,
  bets,
  transactions,
  chatMessages,
  adminSettings,
  referralStats,
  type Profile,
  type InsertProfile,
  type Prediction,
  type InsertPrediction,
  type Bet,
  type InsertBet,
  type Transaction,
  type InsertTransaction,
  type ChatMessage,
  type InsertChatMessage,
  type AdminSetting,
  type InsertAdminSetting,
  type ReferralStats,
  type InsertReferralStats,
} from "@shared/schema";

// Database connection
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
});

const db = drizzle(pool);

export interface IStorage {
  // Profile methods
  getProfile(id: string): Promise<Profile | undefined>;
  getProfileByWallet(walletAddress: string): Promise<Profile | undefined>;
  createProfile(profile: InsertProfile): Promise<Profile>;
  updateProfile(id: string, updates: Partial<InsertProfile>): Promise<Profile | undefined>;
  getAllProfiles(): Promise<Profile[]>;

  // Prediction methods
  getAllPredictions(): Promise<Prediction[]>;
  getPrediction(id: string): Promise<Prediction | undefined>;
  createPrediction(prediction: InsertPrediction): Promise<Prediction>;
  updatePrediction(id: string, updates: Partial<InsertPrediction>): Promise<Prediction | undefined>;
  deletePrediction(id: string): Promise<boolean>;

  // Bet methods
  getAllBets(): Promise<Bet[]>;
  getBetsByUser(userId: string): Promise<Bet[]>;
  getBetsByPrediction(predictionId: string): Promise<Bet[]>;
  createBet(bet: InsertBet): Promise<Bet>;
  updateBet(id: string, updates: Partial<InsertBet>): Promise<Bet | undefined>;

  // Transaction methods
  getTransactionsByUser(userId: string): Promise<Transaction[]>;
  createTransaction(transaction: InsertTransaction): Promise<Transaction>;

  // Chat methods
  getAllChatMessages(): Promise<ChatMessage[]>;
  createChatMessage(message: InsertChatMessage): Promise<ChatMessage>;

  // Admin settings methods
  getAdminSetting(key: string): Promise<AdminSetting | undefined>;
  setAdminSetting(setting: InsertAdminSetting): Promise<AdminSetting>;
  getAllAdminSettings(): Promise<AdminSetting[]>;

  // Referral stats methods
  getReferralStats(userId: string): Promise<ReferralStats | undefined>;
  updateReferralStats(userId: string, stats: Partial<InsertReferralStats>): Promise<ReferralStats>;
}

export class DatabaseStorage implements IStorage {
  // Profile methods
  async getProfile(id: string): Promise<Profile | undefined> {
    const result = await db.select().from(profiles).where(eq(profiles.id, id));
    return result[0];
  }

  async getProfileByWallet(walletAddress: string): Promise<Profile | undefined> {
    const result = await db.select().from(profiles).where(eq(profiles.walletAddress, walletAddress));
    return result[0];
  }

  async createProfile(profile: InsertProfile): Promise<Profile> {
    const result = await db.insert(profiles).values(profile).returning();
    return result[0];
  }

  async updateProfile(id: string, updates: Partial<InsertProfile>): Promise<Profile | undefined> {
    const result = await db.update(profiles).set(updates).where(eq(profiles.id, id)).returning();
    return result[0];
  }

  async getAllProfiles(): Promise<Profile[]> {
    return await db.select().from(profiles).orderBy(desc(profiles.totalVolume));
  }

  // Prediction methods
  async getAllPredictions(): Promise<Prediction[]> {
    return await db.select().from(predictions).orderBy(desc(predictions.createdAt));
  }

  async getPrediction(id: string): Promise<Prediction | undefined> {
    const result = await db.select().from(predictions).where(eq(predictions.id, id));
    return result[0];
  }

  async createPrediction(prediction: InsertPrediction): Promise<Prediction> {
    const result = await db.insert(predictions).values(prediction).returning();
    return result[0];
  }

  async updatePrediction(id: string, updates: Partial<InsertPrediction>): Promise<Prediction | undefined> {
    const result = await db.update(predictions).set(updates).where(eq(predictions.id, id)).returning();
    return result[0];
  }

  async deletePrediction(id: string): Promise<boolean> {
    const result = await db.delete(predictions).where(eq(predictions.id, id));
    return (result.rowCount || 0) > 0;
  }

  // Bet methods
  async getAllBets(): Promise<Bet[]> {
    return await db.select().from(bets).orderBy(desc(bets.createdAt));
  }

  async getBetsByUser(userId: string): Promise<Bet[]> {
    return await db.select().from(bets).where(eq(bets.userId, userId)).orderBy(desc(bets.createdAt));
  }

  async getBetsByPrediction(predictionId: string): Promise<Bet[]> {
    return await db.select().from(bets).where(eq(bets.predictionId, predictionId));
  }

  async createBet(bet: InsertBet): Promise<Bet> {
    const result = await db.insert(bets).values(bet).returning();
    return result[0];
  }

  async updateBet(id: string, updates: Partial<InsertBet>): Promise<Bet | undefined> {
    const result = await db.update(bets).set(updates).where(eq(bets.id, id)).returning();
    return result[0];
  }

  // Transaction methods
  async getTransactionsByUser(userId: string): Promise<Transaction[]> {
    return await db.select().from(transactions).where(eq(transactions.userId, userId)).orderBy(desc(transactions.createdAt));
  }

  async createTransaction(transaction: InsertTransaction): Promise<Transaction> {
    const result = await db.insert(transactions).values(transaction).returning();
    return result[0];
  }

  // Chat methods
  async getAllChatMessages(): Promise<ChatMessage[]> {
    return await db.select().from(chatMessages).orderBy(desc(chatMessages.createdAt)).limit(50);
  }

  async createChatMessage(message: InsertChatMessage): Promise<ChatMessage> {
    const result = await db.insert(chatMessages).values(message).returning();
    return result[0];
  }

  // Admin settings methods
  async getAdminSetting(key: string): Promise<AdminSetting | undefined> {
    const result = await db.select().from(adminSettings).where(eq(adminSettings.key, key));
    return result[0];
  }

  async setAdminSetting(setting: InsertAdminSetting): Promise<AdminSetting> {
    const result = await db.insert(adminSettings).values(setting).onConflictDoUpdate({
      target: adminSettings.key,
      set: { value: setting.value, updatedAt: new Date() }
    }).returning();
    return result[0];
  }

  async getAllAdminSettings(): Promise<AdminSetting[]> {
    return await db.select().from(adminSettings);
  }

  // Referral stats methods
  async getReferralStats(userId: string): Promise<ReferralStats | undefined> {
    const result = await db.select().from(referralStats).where(eq(referralStats.userId, userId));
    return result[0];
  }

  async updateReferralStats(userId: string, stats: Partial<InsertReferralStats>): Promise<ReferralStats> {
    const result = await db.insert(referralStats).values({ userId, ...stats }).onConflictDoUpdate({
      target: referralStats.userId,
      set: { ...stats, updatedAt: new Date() }
    }).returning();
    return result[0];
  }
}

export class MemStorage implements IStorage {
  private profiles: Map<string, Profile> = new Map();
  private predictions: Map<string, Prediction> = new Map();
  private bets: Map<string, Bet> = new Map();
  private transactions: Map<string, Transaction> = new Map();
  private chatMessages: Map<string, ChatMessage> = new Map();
  private adminSettings: Map<string, AdminSetting> = new Map();
  private referralStatsMap: Map<string, ReferralStats> = new Map();

  // Profile methods
  async getProfile(id: string): Promise<Profile | undefined> {
    return this.profiles.get(id);
  }

  async getProfileByWallet(walletAddress: string): Promise<Profile | undefined> {
    return Array.from(this.profiles.values()).find(p => p.walletAddress === walletAddress);
  }

  async createProfile(profile: InsertProfile): Promise<Profile> {
    const id = crypto.randomUUID();
    const newProfile: Profile = {
      id,
      walletAddress: profile.walletAddress,
      username: profile.username || null,
      avatarUrl: profile.avatarUrl || null,
      balance: profile.balance || "0",
      totalVolume: profile.totalVolume || "0",
      totalBets: profile.totalBets || 0,
      winRate: profile.winRate || "0",
      referralCode: profile.referralCode || null,
      referredBy: profile.referredBy || null,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.profiles.set(id, newProfile);
    return newProfile;
  }

  async updateProfile(id: string, updates: Partial<InsertProfile>): Promise<Profile | undefined> {
    const profile = this.profiles.get(id);
    if (!profile) return undefined;
    
    const updated = { ...profile, ...updates, updatedAt: new Date() };
    this.profiles.set(id, updated);
    return updated;
  }

  async getAllProfiles(): Promise<Profile[]> {
    return Array.from(this.profiles.values());
  }

  // Prediction methods
  async getAllPredictions(): Promise<Prediction[]> {
    return Array.from(this.predictions.values());
  }

  async getPrediction(id: string): Promise<Prediction | undefined> {
    return this.predictions.get(id);
  }

  async createPrediction(prediction: InsertPrediction): Promise<Prediction> {
    const id = crypto.randomUUID();
    const newPrediction: Prediction = {
      id,
      question: prediction.question,
      category: prediction.category,
      endTime: prediction.endTime,
      yesPool: prediction.yesPool || "0",
      noPool: prediction.noPool || "0",
      participants: prediction.participants || 0,
      status: prediction.status || "active",
      result: prediction.result || null,
      createdBy: prediction.createdBy || null,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.predictions.set(id, newPrediction);
    return newPrediction;
  }

  async updatePrediction(id: string, updates: Partial<InsertPrediction>): Promise<Prediction | undefined> {
    const prediction = this.predictions.get(id);
    if (!prediction) return undefined;
    
    const updated = { ...prediction, ...updates, updatedAt: new Date() };
    this.predictions.set(id, updated);
    return updated;
  }

  async deletePrediction(id: string): Promise<boolean> {
    return this.predictions.delete(id);
  }

  // Bet methods
  async getAllBets(): Promise<Bet[]> {
    return Array.from(this.bets.values());
  }

  async getBetsByUser(userId: string): Promise<Bet[]> {
    return Array.from(this.bets.values()).filter(bet => bet.userId === userId);
  }

  async getBetsByPrediction(predictionId: string): Promise<Bet[]> {
    return Array.from(this.bets.values()).filter(bet => bet.predictionId === predictionId);
  }

  async createBet(bet: InsertBet): Promise<Bet> {
    const id = crypto.randomUUID();
    const newBet: Bet = {
      id,
      userId: bet.userId,
      predictionId: bet.predictionId,
      amount: bet.amount,
      position: bet.position,
      potentialPayout: bet.potentialPayout || null,
      isResolved: bet.isResolved || false,
      actualPayout: bet.actualPayout || "0",
      createdAt: new Date(),
    };
    this.bets.set(id, newBet);
    return newBet;
  }

  async updateBet(id: string, updates: Partial<InsertBet>): Promise<Bet | undefined> {
    const bet = this.bets.get(id);
    if (!bet) return undefined;
    
    const updated = { ...bet, ...updates };
    this.bets.set(id, updated);
    return updated;
  }

  // Transaction methods
  async getTransactionsByUser(userId: string): Promise<Transaction[]> {
    return Array.from(this.transactions.values()).filter(tx => tx.userId === userId);
  }

  async createTransaction(transaction: InsertTransaction): Promise<Transaction> {
    const id = crypto.randomUUID();
    const newTransaction: Transaction = {
      id,
      userId: transaction.userId,
      type: transaction.type,
      amount: transaction.amount,
      status: transaction.status || "completed",
      description: transaction.description || null,
      transactionHash: transaction.transactionHash || null,
      createdAt: new Date(),
    };
    this.transactions.set(id, newTransaction);
    return newTransaction;
  }

  // Chat methods
  async getAllChatMessages(): Promise<ChatMessage[]> {
    return Array.from(this.chatMessages.values());
  }

  async createChatMessage(message: InsertChatMessage): Promise<ChatMessage> {
    const id = crypto.randomUUID();
    const newMessage: ChatMessage = {
      ...message,
      id,
      createdAt: new Date(),
    };
    this.chatMessages.set(id, newMessage);
    return newMessage;
  }

  // Admin settings methods
  async getAdminSetting(key: string): Promise<AdminSetting | undefined> {
    return this.adminSettings.get(key);
  }

  async setAdminSetting(setting: InsertAdminSetting): Promise<AdminSetting> {
    const id = crypto.randomUUID();
    const newSetting: AdminSetting = {
      ...setting,
      id,
      updatedAt: new Date(),
    };
    this.adminSettings.set(setting.key, newSetting);
    return newSetting;
  }

  async getAllAdminSettings(): Promise<AdminSetting[]> {
    return Array.from(this.adminSettings.values());
  }

  // Referral stats methods
  async getReferralStats(userId: string): Promise<ReferralStats | undefined> {
    return this.referralStatsMap.get(userId);
  }

  async updateReferralStats(userId: string, stats: Partial<InsertReferralStats>): Promise<ReferralStats> {
    const existing = this.referralStatsMap.get(userId);
    const id = existing?.id || crypto.randomUUID();
    const updated: ReferralStats = {
      id,
      userId,
      totalReferrals: 0,
      totalEarnings: "0",
      activeReferrals: 0,
      ...existing,
      ...stats,
      updatedAt: new Date(),
    };
    this.referralStatsMap.set(userId, updated);
    return updated;
  }
}

// Use DatabaseStorage for production, MemStorage for development
export const storage = process.env.NODE_ENV === 'production' ? new DatabaseStorage() : new MemStorage();
